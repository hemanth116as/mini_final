import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css'; // Import CSS file for navbar styles
import logoImage from "C:/Users/91934/OneDrive/Desktop/mini_project/src/images/logo.jpeg";
import SignInModal from './SignInModal';

const Navbar = () => {
  const [showSignInModal, setShowSignInModal] = useState(false);

  const openSignInModal = () => {
    setShowSignInModal(true);
    // document.body.classList.add('modal-open'); // Apply class to blur background
  };

  const closeSignInModal = () => {
    setShowSignInModal(false);
    document.body.classList.remove('modal-open'); // Remove class to unblur background
  };

  // const fetchTimetables = async () => {
  //   try {
  //     const response = await fetch('http://localhost:5000/get_timetables'); // Assuming this is your Flask route to fetch timetables
  //     const data = await response.json();
  //     setTimetableData(data);
  //   } catch (error) {
  //     console.error('Error fetching timetables:', error);
  //   }
  // };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <img src={logoImage} alt="Logo" className="logo" />
        <h1>Faculty Roster Management</h1>
        <ul className="nav-links">
          <li className="nav-item"><Link to="/home" className="nav-link">Home</Link></li>
          <li className="nav-item"><a href="#sign-in" className="nav-link" onClick={openSignInModal}>Sign in</a></li>
          <li className="nav-item"><Link to="/regular_tt" className="nav-link" >Regular Timetables</Link></li>
          <li className="nav-item dropdown">
            Departments
            <ul className="dropdown-content">
              <li><a href="http://www.geethanjaliinstitutions.com/engineering/cse.html">CSE</a></li>
              <li><a href="http://www.geethanjaliinstitutions.com/engineering/it.html">IT</a></li>
              <li><a href="http://www.geethanjaliinstitutions.com/engineering/ece.html">ECE</a></li>
              {/* Add more department options as needed */}
            </ul>
          </li>
        </ul>
      </div>
      {showSignInModal && <SignInModal onClose={closeSignInModal} />}
    </nav>
  );
};

export default Navbar;
