import React from "react";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import logoImage from "C:/Users/91934/OneDrive/Desktop/mini_project/src/images/image2.jpeg";
import imageImage from "C:/Users/91934/OneDrive/Desktop/mini_project/src/images/image1.jpeg";
import image1Image from "C:/Users/91934/OneDrive/Desktop/mini_project/src/images/image3.jpeg";

const images = [
  logoImage,
  imageImage,
  image1Image
];

function Carousels() {
  return (
    <div className="carousel-container">
      <Carousel 
        showArrows={true}    // Disable navigation arrows
        showStatus={true}     // Enable status indicator
        showThumbs={false} 
        showIndicators={true}   // Disable thumbnail navigation
        autoPlay={true}       // Enable autoplay
        interval={1500}       // Set interval time (1.5 seconds)
        infiniteLoop={true}   // Enable infinite loop
        stopOnHover={false}   // Ensure autoplay continues when hovering over the carousel
        renderThumbs={() => null}
      >
        {images.map((URL, index) => (
          <div 
            className="slide" 
            key={index} 
            style={{ width: '50%', height: '80%' }} // Apply resizing styles
          >
            <img 
              alt={`Slide ${index + 1}`} 
              src={URL} 
              style={{ width: '50%', height: '80%' }} // Ensure image fills its container
            />
          </div>
        ))}
      </Carousel>
    </div>
  );
}

export default Carousels;
