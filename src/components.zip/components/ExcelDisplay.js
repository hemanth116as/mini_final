import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { ExcelRenderer } from 'react-excel-renderer';

const ExcelDisplay = () => {
  const [excelFiles, setExcelFiles] = useState([]);
  const [excelData, setExcelData] = useState([]);

  useEffect(() => {
    fetchExcelFiles();
  }, []);

  const fetchExcelFiles = async () => {
    try {
      const response = await axios.get('http://localhost:5000/get_excel_files');
      setExcelFiles(response.data);
    } catch (error) {
      console.error('Error fetching Excel files:', error);
    }
  };

  const displayExcelData = async (filename) => {
    try {
      const response = await axios.get(`http://localhost:5000/get_excel_data/${filename}`, { responseType: 'blob' });
      const blob = new Blob([response.data]);
      ExcelRenderer(blob, (err, resp) => {
        if (err) {
          console.error('Error parsing Excel data:', err);
        } else {
          console.log('Parsed Excel data:', resp);
          
          // Check if resp and resp.rows are defined
          if (resp && resp.rows && resp.rows.length > 0) {
            // Set the parsed Excel data to state
            setExcelData(resp.rows); // Set rows directly
          } else {
            console.error('Invalid response data:', resp);
          }
          const columnIndexA = resp.cols.findIndex(col => col.name === 'C');

          // Find the index of row "Monday"
          const rowIndexMonday = resp.rows.findIndex(row => row[0] === 'Monday');

          // Print the value at row "Monday" and column "A"
          const value = resp.rows[rowIndexMonday][columnIndexA];
          console.log(value)
        }
      });
    } catch (error) {
      console.error('Error fetching Excel data:', error);
    }
  };
  

  return (
    <div>
      <h2>Available Excel Files:</h2>
      <ul>
        {excelFiles.map((filename, index) => (
          <li key={index} onClick={() => displayExcelData(filename)}>
            {filename}
          </li>
        ))}
      </ul>
      
      <h2>Parsed Excel Data:</h2>
      <table>
        <tbody>
        {excelData && excelData.length > 0 && excelData.map((row, rowIndex) => (
  <tr key={rowIndex}>
    {row.map((cell, cellIndex) => (
      <td key={cellIndex}>{cell}</td>
    ))}
  </tr>
))}

        </tbody>
      </table>
    </div>
  );
};

export default ExcelDisplay;
